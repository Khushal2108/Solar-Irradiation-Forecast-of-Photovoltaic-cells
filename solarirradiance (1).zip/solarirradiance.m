cd('C:\Users\Downloads')
%% Load data
data = readtable('solar_irradiance_data.xlsx', 'Sheet', 1);
y = data.Irradiance;
% Resample data to hourly intervals
y = mean(reshape(y, 4, []));

%% Define ARIMA model
model = arima('ARLags', 1, 'MALags', 1, 'Constant', 0);
[fit,~,logL] = estimate(model, y');

%% Make predictions for next day's solar irradiance
last_day_irradiance = y(end);
num_predictions = 5000;
future_irradiance = NaN(num_predictions, 1);
for i = 1:num_predictions
    future_irradiance(i) = simulate(fit, 1, 'Y0', last_day_irradiance);
end

%% Compute summary statistics for predicted values
mean_prediction = mean(future_irradiance);
median_prediction = median(future_irradiance);
credible_interval = prctile(future_irradiance, [2.5, 97.5]);

%% Plot posterior distributions and predictions
figure;
subplot(2,1,1);
resid = infer(fit, y');
plot(resid);
title('Residuals of ARIMA fit');
ylabel('Residual');

subplot(2,1,2);
histogram(future_irradiance, 30);
hold on;
line([mean_prediction, mean_prediction], ylim, 'LineWidth', 1, 'Color', 'r', 'LineStyle', '--', 'DisplayName', 'Mean prediction');
line([median_prediction, median_prediction], ylim, 'LineWidth', 1, 'Color', 'g', 'LineStyle', '--', 'DisplayName', 'Median prediction');
line([credible_interval(1), credible_interval(1)], ylim, 'LineWidth', 1, 'Color', 'k', 'LineStyle', '--', 'DisplayName', '95% credible interval');
line([credible_interval(2), credible_interval(2)], ylim, 'LineWidth', 1, 'Color', 'k', 'LineStyle', '--');
hold off;
title('Posterior distribution of next day''s solar irradiance');
ylabel('Frequency');
legend('Location', 'best'); 